/* jpea_v2_image_world_model.cpp - Factory and fallback for image world model interface
   Copyright (C) 2026 079 Project

   This file is part of 079 Project.

   079 Project is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version. */

#include "jpea_v2_image_world_model.hpp"
#include "rdk_x5_bpu.hpp"

#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <string>

#if __has_include(<opencv2/opencv.hpp>)
#define JPEA_HAVE_OPENCV 1
#include <opencv2/opencv.hpp>
#else
#define JPEA_HAVE_OPENCV 0
#endif

namespace phoenix {
namespace io {

namespace {

class JpeaV2ImageHbdnnModel : public JpeaV2ImageWorldModel {
 public:
  JpeaV2ImageHbdnnModel(JpeaV2ImageWorldModelConfig cfg, int targetDim)
      : cfg_(std::move(cfg)), targetDim_(targetDim > 0 ? targetDim : 128),
        modelPath_(environment("JPEA_IMAGE_HORIZON_MODEL")),
        color_(environment("JPEA_IMAGE_INPUT_COLOR", "bgr")) {}

  std::vector<float> encode(const std::vector<uint8_t> &imageBytes, int width, int height,
                            const std::string &mimeType) override {
#if !JPEA_HAVE_OPENCV
    lastError_ = "OpenCV image decoding is unavailable in this build";
    return {};
#else
    if (modelPath_.empty()) {
      lastError_ = "JPEA_IMAGE_HORIZON_MODEL is required";
      return {};
    }
    if (!rdk_x5_bpu::available()) {
      lastError_ = "RDK X5 hbDNN runtime is unavailable";
      return {};
    }
    cv::Mat image;
    if (mimeType == "application/x-bgr") {
      if (width <= 0 || height <= 0 || imageBytes.size() != static_cast<size_t>(width) * static_cast<size_t>(height) * 3U) {
        lastError_ = "direct BGR frame does not match its declared dimensions";
        return {};
      }
      image = cv::Mat(height, width, CV_8UC3, const_cast<uint8_t *>(imageBytes.data())).clone();
    } else {
      std::vector<uchar> compressed(imageBytes.begin(), imageBytes.end());
      image = cv::imdecode(compressed, cv::IMREAD_COLOR);
      if (image.empty()) {
        lastError_ = "unable to decode image payload";
        return {};
      }
    }
    cv::resize(image, image, cv::Size(cfg_.resolution, cfg_.resolution), 0, 0, cv::INTER_AREA);
    if (color_ == "rgb") cv::cvtColor(image, image, cv::COLOR_BGR2RGB);
    if (color_ != "bgr" && color_ != "rgb") {
      lastError_ = "JPEA_IMAGE_INPUT_COLOR must be bgr or rgb";
      return {};
    }
    const std::filesystem::path inputPath = temporaryInputPath();
    {
      std::ofstream output(inputPath, std::ios::binary | std::ios::trunc);
      output.write(reinterpret_cast<const char *>(image.data),
                   static_cast<std::streamsize>(image.total() * image.elemSize()));
      if (!output) {
        lastError_ = "unable to write BPU input tensor";
        return {};
      }
    }
    const auto result = rdk_x5_bpu::execute(nlohmann::json{{"bpuModelPath", modelPath_},
                                                              {"bpuInputPath", inputPath.string()},
                                                              {"maxBpuOutputValues", targetDim_}});
    std::error_code ec;
    std::filesystem::remove(inputPath, ec);
    if (!result.value("executed", false)) {
      lastError_ = result.value("error", std::string("hbDNN inference failed"));
      return {};
    }
    const auto outputs = result.value("outputs", nlohmann::json::array());
    if (!outputs.is_array() || outputs.empty() || !outputs[0].contains("values") || !outputs[0]["values"].is_array()) {
      lastError_ = "JPEA Horizon model must expose a float embedding output";
      return {};
    }
    const auto embedding = outputs[0]["values"].get<std::vector<float>>();
    if (static_cast<int>(embedding.size()) != targetDim_) {
      lastError_ = "JPEA embedding output dimension does not match JPEA_IMAGE_CONCEPT_DIM";
      return {};
    }
    ++samples_;
    lastError_.clear();
    return embedding;
#endif
  }

  std::vector<float> encodeContext(const std::vector<uint8_t> &imageBytes, int width, int height,
                                   const std::string &mimeType, const std::vector<bool> &) override {
    return encode(imageBytes, width, height, mimeType);
  }

  std::vector<float> encodeTarget(const std::vector<uint8_t> &, int, int, const std::string &,
                                  const std::vector<int> &) override {
    lastError_ = "target encoding requires a compiled masked-target JPEA graph";
    return {};
  }

  std::vector<float> predictTarget(const std::vector<float> &, const std::vector<int> &) override {
    lastError_ = "target prediction requires a compiled JPEA predictor graph";
    return {};
  }

  float adapt(const std::vector<uint8_t> &, int, int, const std::string &, int, float) override {
    lastError_ = "runtime adaptation is not supported by an immutable Horizon model";
    return -1.0f;
  }

  std::vector<uint8_t> decode(const std::vector<float> &, const std::string &) override {
    lastError_ = "JPEA encoder deployment has no image decoder";
    return {};
  }

  nlohmann::json status() const override {
    return nlohmann::json{{"id", cfg_.id}, {"arch", cfg_.arch}, {"backend", "horizon-hbdnn"},
                          {"resolution", cfg_.resolution}, {"patchSize", cfg_.patchSize},
                          {"targetDim", targetDim_}, {"samples", samples_}, {"modelPath", modelPath_},
                          {"inputColor", color_}, {"ready", !modelPath_.empty() && std::filesystem::is_regular_file(modelPath_) && rdk_x5_bpu::available()},
                          {"error", lastError_}};
  }

  const JpeaV2ImageWorldModelConfig &config() const override { return cfg_; }

 private:
  static std::string environment(const char *name, const std::string &defaultValue = {}) {
    const char *value = std::getenv(name);
    return value != nullptr ? std::string(value) : defaultValue;
  }

  static std::filesystem::path temporaryInputPath() {
    static std::atomic<uint64_t> sequence{0};
    return std::filesystem::temp_directory_path() /
           ("phoenix-jpea-" + std::to_string(sequence.fetch_add(1)) + ".tensor");
  }

  JpeaV2ImageWorldModelConfig cfg_;
  int targetDim_;
  std::string modelPath_;
  std::string color_;
  size_t samples_ = 0;
  std::string lastError_;
};

}  // namespace

std::unique_ptr<JpeaV2ImageWorldModel> createJpeaV2ImageWorldModel(
    const std::string &variantId, int targetDim, const std::string & /*backend*/) {
  const auto *v = findJpeaV2ImageVariant(variantId);
  if (!v) {
    // Default to lowest-compute official variant if id is unknown.
    v = findJpeaV2ImageVariant("ijepa_vith14_1k");
  }
  return std::make_unique<JpeaV2ImageHbdnnModel>(*v, targetDim);
}

}  // namespace io
}  // namespace phoenix
