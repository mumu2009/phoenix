#include "rdk_x5_bpu.hpp"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

#if __has_include(<dnn/hb_dnn.h>)
#include <dnn/hb_dnn.h>
#define PHOENIX_RDK_X5_HAVE_HBDNN 1
#endif

namespace rdk_x5_bpu {

namespace {

namespace fs = std::filesystem;

std::string modelPath(const json &payload) {
    if (!payload.is_object()) {
        return {};
    }
    return payload.value("bpuModelPath", payload.value("horizonModelPath", std::string()));
}

std::string inputPath(const json &payload) {
    if (!payload.is_object()) {
        return {};
    }
    return payload.value("bpuInputPath", payload.value("inputPath", std::string()));
}

bool devicePresent() {
    std::error_code ec;
    return fs::exists("/dev/bpu", ec) || fs::exists("/dev/bpu_core0", ec);
}

#ifdef PHOENIX_RDK_X5_HAVE_HBDNN
json outputSummary(hbDNNHandle_t modelHandle, hbDNNTensor *outputTensors, int maxValues) {
    int32_t outputCount = 0;
    int32_t status = hbDNNGetOutputCount(&outputCount, modelHandle);
    if (status != 0 || outputCount < 1) {
        return json{{"error", "hbDNNGetOutputCount failed: " + std::to_string(status)}};
    }

    json outputs = json::array();
    for (int32_t index = 0; index < outputCount; ++index) {
        hbDNNTensorProperties properties{};
        status = hbDNNGetOutputTensorProperties(&properties, modelHandle, index);
        if (status != 0) {
            return json{{"error", "hbDNNGetOutputTensorProperties failed: " + std::to_string(status)}};
        }
        hbSysFlushMem(&outputTensors[index].sysMem[0], HB_SYS_MEM_CACHE_INVALIDATE);
        json output{{"index", index},
                    {"bytes", properties.alignedByteSize},
                    {"tensorType", properties.tensorType},
                    {"shape", json::array()}};
        for (int dimension = 0; dimension < properties.validShape.numDimensions; ++dimension) {
            output["shape"].push_back(properties.validShape.dimensionSize[dimension]);
        }
        if (properties.tensorType == HB_DNN_TENSOR_TYPE_F32 && outputTensors[index].sysMem[0].virAddr != nullptr) {
            const float *values = static_cast<const float *>(outputTensors[index].sysMem[0].virAddr);
            const int count = std::min(maxValues, properties.alignedByteSize / static_cast<int32_t>(sizeof(float)));
            output["values"] = json::array();
            for (int value = 0; value < count; ++value) {
                output["values"].push_back(values[value]);
            }
        }
        outputs.push_back(std::move(output));
    }
    return outputs;
}
#endif

} // namespace

bool available() {
#ifdef PHOENIX_RDK_X5_HAVE_HBDNN
    return devicePresent();
#else
    return false;
#endif
}

bool requested(const json &payload) {
    return !modelPath(payload).empty();
}

json inspect(const json &payload) {
    const std::string path = modelPath(payload);
    std::error_code ec;
    return json{{"requested", !path.empty()},
                {"available", available()},
#ifdef PHOENIX_RDK_X5_HAVE_HBDNN
                {"runtime", "hbDNN 1.24"},
#else
                {"runtime", "hbDNN headers unavailable"},
#endif
                {"modelPath", path},
                {"modelExists", !path.empty() && fs::is_regular_file(path, ec)}};
}

json execute(const json &payload) {
#ifndef PHOENIX_RDK_X5_HAVE_HBDNN
    return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNN headers are unavailable at build time"}};
#else
    const std::string model = modelPath(payload);
    const std::string input = inputPath(payload);
    if (model.empty() || input.empty()) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "bpuModelPath and bpuInputPath are required"}};
    }
    if (!available()) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "RDK X5 BPU device nodes are unavailable"}};
    }

    std::ifstream inputFile(input, std::ios::binary);
    if (!inputFile) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "failed to open input: " + input}};
    }
    const std::vector<char> bytes((std::istreambuf_iterator<char>(inputFile)), std::istreambuf_iterator<char>());
    if (bytes.empty()) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "input is empty"}};
    }

    hbPackedDNNHandle_t packed = nullptr;
    const char *modelFiles[] = {model.c_str()};
    int32_t status = hbDNNInitializeFromFiles(&packed, modelFiles, 1);
    if (status != 0 || packed == nullptr) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNInitializeFromFiles failed: " + std::to_string(status)}};
    }
    struct PackedGuard { hbPackedDNNHandle_t handle; ~PackedGuard() { hbDNNRelease(handle); } } packedGuard{packed};

    char const **names = nullptr;
    int32_t modelCount = 0;
    status = hbDNNGetModelNameList(&names, &modelCount, packed);
    if (status != 0 || modelCount < 1 || names == nullptr) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNGetModelNameList failed: " + std::to_string(status)}};
    }
    const std::string requestedName = payload.value("bpuModelName", std::string());
    const char *name = names[0];
    for (int32_t index = 0; index < modelCount; ++index) {
        if (requestedName == names[index]) {
            name = names[index];
            break;
        }
    }

    hbDNNHandle_t modelHandle = nullptr;
    status = hbDNNGetModelHandle(&modelHandle, packed, name);
    int32_t inputCount = 0;
    if (status != 0 || hbDNNGetInputCount(&inputCount, modelHandle) != 0 || inputCount != 1) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "only valid single-input BPU models are supported"}};
    }
    hbDNNTensorProperties inputProperties{};
    status = hbDNNGetInputTensorProperties(&inputProperties, modelHandle, 0);
    if (status != 0 || inputProperties.alignedByteSize <= 0 || bytes.size() != static_cast<std::size_t>(inputProperties.alignedByteSize)) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "input byte count must equal model aligned input size"}, {"expectedBytes", inputProperties.alignedByteSize}, {"actualBytes", bytes.size()}};
    }

    hbDNNTensor inputTensor{};
    inputTensor.properties = inputProperties;
    status = hbSysAllocCachedMem(&inputTensor.sysMem[0], static_cast<uint32_t>(inputProperties.alignedByteSize));
    if (status != 0 || inputTensor.sysMem[0].virAddr == nullptr) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbSysAllocCachedMem failed: " + std::to_string(status)}};
    }
    struct MemoryGuard { hbSysMem *memory; ~MemoryGuard() { hbSysFreeMem(memory); } } memoryGuard{&inputTensor.sysMem[0]};
    std::memcpy(inputTensor.sysMem[0].virAddr, bytes.data(), bytes.size());
    status = hbSysFlushMem(&inputTensor.sysMem[0], HB_SYS_MEM_CACHE_CLEAN);
    if (status != 0) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbSysFlushMem failed: " + std::to_string(status)}};
    }

    int32_t outputCount = 0;
    status = hbDNNGetOutputCount(&outputCount, modelHandle);
    if (status != 0 || outputCount < 1) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNGetOutputCount failed: " + std::to_string(status)}};
    }
    std::vector<hbDNNTensor> outputStorage(static_cast<std::size_t>(outputCount));
    for (int32_t index = 0; index < outputCount; ++index) {
        status = hbDNNGetOutputTensorProperties(&outputStorage[index].properties, modelHandle, index);
        if (status != 0 || outputStorage[index].properties.alignedByteSize <= 0) {
            return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNGetOutputTensorProperties failed: " + std::to_string(status)}};
        }
        status = hbSysAllocCachedMem(&outputStorage[index].sysMem[0], static_cast<uint32_t>(outputStorage[index].properties.alignedByteSize));
        if (status != 0 || outputStorage[index].sysMem[0].virAddr == nullptr) {
            for (int32_t allocated = 0; allocated < index; ++allocated) {
                hbSysFreeMem(&outputStorage[allocated].sysMem[0]);
            }
            return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbSysAllocCachedMem for output failed: " + std::to_string(status)}};
        }
    }
    struct OutputsGuard {
        std::vector<hbDNNTensor> &tensors;
        ~OutputsGuard() { for (auto &tensor : tensors) { if (tensor.sysMem[0].virAddr != nullptr) hbSysFreeMem(&tensor.sysMem[0]); } }
    } outputsGuard{outputStorage};

    hbDNNInferCtrlParam control{};
    HB_DNN_INITIALIZE_INFER_CTRL_PARAM(&control);
    control.bpuCoreId = payload.value("bpuCoreId", static_cast<int>(HB_BPU_CORE_ANY));
    control.priority = payload.value("bpuPriority", static_cast<int>(HB_DNN_PRIORITY_LOWEST));
    hbDNNTaskHandle_t task = nullptr;
    hbDNNTensor *outputs = outputStorage.data();
    const auto started = std::chrono::steady_clock::now();
    status = hbDNNInfer(&task, &outputs, &inputTensor, modelHandle, &control);
    if (status != 0 || task == nullptr || outputs == nullptr) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNInfer failed: " + std::to_string(status)}};
    }
    struct TaskGuard { hbDNNTaskHandle_t task; ~TaskGuard() { hbDNNReleaseTask(task); } } taskGuard{task};
    status = hbDNNWaitTaskDone(task, std::max(1, payload.value("bpuTimeoutMs", 5000)));
    const auto elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - started).count();
    if (status != 0) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", "hbDNNWaitTaskDone failed: " + std::to_string(status)}, {"totalElapsedMs", elapsed}};
    }
    json outputsJson = outputSummary(modelHandle, outputs, std::clamp(payload.value("maxBpuOutputValues", 128), 0, 4096));
    if (outputsJson.is_object() && outputsJson.contains("error")) {
        return json{{"executed", false}, {"driver", "horizon-hbdnn"}, {"error", outputsJson["error"]}};
    }
    return json{{"executed", true}, {"driver", "horizon-hbdnn"}, {"model", name}, {"bpuCoreId", control.bpuCoreId}, {"totalElapsedMs", elapsed}, {"outputs", outputsJson}};
#endif
}

} // namespace rdk_x5_bpu
